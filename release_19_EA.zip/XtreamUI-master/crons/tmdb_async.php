<?php
include "/home/xtreamcodes/iptv_xtream_codes/admin/functions.php";
include "/home/xtreamcodes/iptv_xtream_codes/admin/tmdb.php";
include "/home/xtreamcodes/iptv_xtream_codes/admin/tmdb_release.php";

$rAdminSettings = getAdminSettings();
$rSettings = getSettings();
$rCategories = getCategories();
$rServers = getStreamingServers();

$rPID = getmypid();
if (isset($rAdminSettings["tmdb_pid"])) {
    if (file_exists("/proc/".$rAdminSettings["tmdb_pid"])) {
        exit;
    } else {
        $db->query("UPDATE `admin_settings` SET `value` = ".intval($rPID)." WHERE `type` = 'tmdb_pid';");
    }
} else {
    $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('tmdb_pid', ".intval($rPID).");");
}

$rLimit = 250;      // Limit by quantity.
$rTimeout = 3000;   // Limit by time.

set_time_limit($rTimeout);
ini_set('mysql.connect_timeout', $rTimeout);
ini_set('max_execution_time', $rTimeout);
ini_set('default_socket_timeout', $rTimeout);

if (strlen($rAdminSettings["tmdb_language"]) > 0) {
    $rTMDB = new TMDB($rSettings["tmdb_api_key"], $rAdminSettings["tmdb_language"]);
} else {
    $rTMDB = new TMDB($rSettings["tmdb_api_key"]);
}

$rResult = $db->query("SELECT `id`, `type`, `stream_id` FROM `tmdb_async` WHERE`status` = 0 ORDER BY `stream_id` ASC LIMIT ".intval($rLimit).";");
if (($rResult) && ($rResult->num_rows > 0)) {
    while ($rRow = $rResult->fetch_assoc()) {
        $rResultB = $db->query("SELECT * FROM `streams` WHERE `id` = ".intval($rRow["stream_id"]).";");
        if (($rResultB) && ($rResultB->num_rows == 1)) {
            if ($rRow["type"] == 1) {
                $rStream = $rResultB->fetch_assoc();
                $rFilename = pathinfo($rStream["stream_display_name"])["filename"];
                $rRelease = new Release($rFilename);
                $rTitle = $rRelease->getTitle();
                $rYear = $rRelease->getYear();
                $rResults = $rTMDB->searchMovie($rTitle);
                $rMatch = null;
                foreach ($rResults as $rResultArr) {
                    if ($rYear) {
                        $rResultYear = intval(substr($rResultArr->get("release_date"), 0, 4));
                        if ($rResultYear == $rYear) {
                            $rMatch = $rResultArr;
                            break;
                        }
                    } else {
                        $rMatch = $rResultArr;
                        break;
                    }
                }
                if ($rMatch) {
                    $rMovie = $rTMDB->getMovie($rMatch->get("id"));
                    $rMovieData = json_decode($rMovie->getJSON(), True);
                    $rMovieData["trailer"] = $rMovie->getTrailer();
                    $rThumb = "https://image.tmdb.org/t/p/w600_and_h900_bestv2".$rMovieData['poster_path'];
                    $rBG = "https://image.tmdb.org/t/p/w1280".$rMovieData['backdrop_path'];
                    if ($rAdminSettings["download_images"]) {
                        $rThumb = downloadImage($rThumb);
                        $rBG = downloadImage($rBG);
                    } else {
                        sleep(1); // Avoid limits.
                    }
                    $rCast = Array();
                    foreach ($rMovieData["credits"]["cast"] as $rMember) {
                        if (count($rCast) < 5) {
                            $rCast[] = $rMember["name"];
                        }
                    }
                    $rDirectors = Array();
                    foreach ($rMovieData["credits"]["crew"] as $rMember) {
                        if ((count($rDirectors) < 5) && ($rMember["department"] == "Directing")) {
                            $rDirectors[] = $rMember["name"];
                        }
                    }
                    $rCountry = "";
                    if (isset($rMovieData["production_countries"][0]["name"])) {
                        $rCountry = $rMovieData["production_countries"][0]["name"];
                    }
                    $rGenres = Array();
                    foreach ($rMovieData["genres"] as $rGenre) {
                        if (count($rGenres) < 3) {
                            $rGenres[] = $rGenre["name"];
                        }
                    }
                    $rSeconds = intval($rMovieData["runtime"]) * 60;
                    $rProperties = Array("kinopoisk_url" => "https://www.themoviedb.org/movie/".$rMovieData["id"], "tmdb_id" => $rMovieData["id"], "name" => $rMovieData["title"], "o_name" => $rMovieData["original_title"], "cover_big" => $rThumb, "movie_image" => $rThumb, "releasedate" => $rMovieData["release_date"], "episode_run_time" => $rMovieData["runtime"], "youtube_trailer" => $rMovieData["trailer"], "director" => join(", ", $rDirectors), "actors" => join(", ", $rCast), "cast" => join(", ", $rCast), "description" => $rMovieData["overview"], "plot" => $rMovieData["overview"], "age" => "", "mpaa_rating" => "", "rating_count_kinopoisk" => 0, "country" => $rCountry, "genre" => join(", ", $rGenres), "backdrop_path" => Array($rBG), "duration_secs" => $rSeconds, "duration" => sprintf('%02d:%02d:%02d', ($rSeconds/3600),($rSeconds/60%60), $rSeconds%60), "video" => Array(), "audio" => Array(), "bitrate" => 0, "rating" => $rMovieData["vote_average"]);
                    $db->query("UPDATE `tmdb_async` SET `status` = 1 WHERE `id` = ".intval($rRow["id"]).";");
                    $db->query("UPDATE `streams` SET `stream_display_name` = '".$db->real_escape_string($rMovieData["title"])."', `movie_propeties` = '".$db->real_escape_string(json_encode($rProperties))."' WHERE `id` = ".intval($rRow["stream_id"]).";");
                } else {
                    $db->query("UPDATE `tmdb_async` SET `status` = -1 WHERE `id` = ".intval($rRow["id"]).";");
                }
            }
        } else {
            $db->query("UPDATE `tmdb_async` SET `status` = -2 WHERE `id` = ".intval($rRow["id"]).";");
        }
    }
}
?>