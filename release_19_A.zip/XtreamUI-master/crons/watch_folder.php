<?php
// Series coming soon!
include "/home/xtreamcodes/iptv_xtream_codes/admin/functions.php";
include "/home/xtreamcodes/iptv_xtream_codes/admin/tmdb.php";
include "/home/xtreamcodes/iptv_xtream_codes/admin/tmdb_release.php";

$rAdminSettings = getAdminSettings();
$rSettings = getSettings();
$rCategories = getCategories("movie");
$rServers = getStreamingServers();
$rWatchCategories = getWatchCategories(1);

$rResult = $db->query("SELECT * FROM `watch_settings`;");
if (($rResult) && ($rResult->num_rows == 1)) {
    $rWatchSettings = $rResult->fetch_assoc();
}

$rPID = getmypid();
if (isset($rAdminSettings["watch_pid"])) {
    if (file_exists("/proc/".$rAdminSettings["watch_pid"])) {
        exit;
    } else {
        $db->query("UPDATE `admin_settings` SET `value` = ".intval($rPID)." WHERE `type` = 'watch_pid';");
    }
} else {
    $db->query("INSERT INTO `admin_settings`(`type`, `value`) VALUES('watch_pid', ".intval($rPID).");");
}

$rTimeout = 3000;       // Limit by time.
$rScanOffset = intval($rWatchSettings["scan_seconds"]) ?: 3600;

set_time_limit($rTimeout);
ini_set('max_execution_time', $rTimeout);

if (strlen($rSettings["tmdb_api_key"]) == 0) { exit; }

if (strlen($rAdminSettings["tmdb_language"]) > 0) {
    $rTMDB = new TMDB($rSettings["tmdb_api_key"], $rAdminSettings["tmdb_language"]);
} else {
    $rTMDB = new TMDB($rSettings["tmdb_api_key"]);
}

if ($rAdminSettings["local_api"]) {
    $rAPI = "http://127.0.0.1:".$rServers[$_INFO["server_id"]]["http_broadcast_port"]."/api.php";
} else {
    $rAPI = "http://".$rServers[$_INFO["server_id"]]["server_ip"].":".$rServers[$_INFO["server_id"]]["http_broadcast_port"]."/api.php";
}

$rStreamDatabase = Array();
$result = $db->query("SELECT `stream_source` FROM `streams` WHERE `type` = 2;");
if (($result) && ($result->num_rows > 0)) {
    while ($row = $result->fetch_assoc()) {
        foreach (json_decode($row["stream_source"], True) as $rSource) {
            if (strlen($rSource) > 0) {
                $rStreamDatabase[] = $rSource;
            }
        }
    }
}

$rChanged = False;
$rArray = Array("movie_symlink" => 0, "type" => 2, "target_container" => Array("mp4"), "added" => time(), "read_native" => 0, "stream_all" => 0, "redirect_stream" => 1, "direct_source" => 0, "gen_timestamps" => 1, "transcode_attributes" => Array(), "stream_display_name" => "", "stream_source" => Array(), "movie_subtitles" => Array(), "category_id" => 0, "stream_icon" => "", "notes" => "", "custom_sid" => "", "custom_ffmpeg" => "", "transcode_profile_id" => 0, "enable_transcode" => 0, "auto_restart" => "[]", "allow_record" => 0, "rtmp_output" => 0, "epg_id" => null, "channel_id" => null, "epg_lang" => null, "tv_archive_server_id" => 0, "tv_archive_duration" => 0, "delay_minutes" => 0, "external_push" => Array(), "probesize_ondemand" => 128000);
$rResult = $db->query("SELECT * FROM `watch_folders` WHERE `active` = 1 AND UNIX_TIMESTAMP() - `last_run` > ".intval($rScanOffset)." ORDER BY `id` ASC;");
if (($rResult) && ($rResult->num_rows > 0)) {
    while ($rRow = $rResult->fetch_assoc()) {
        $db->query("UPDATE `watch_folders` SET `last_run` = UNIX_TIMESTAMP() WHERE `id` = ".intval($rRow["id"]).";");
        $rImportStreams = Array();
        $rFiles = scanRecursive(intval($rRow["server_id"]), rtrim($rRow["directory"], "/"), Array("mp4", "mkv", "avi", "mpg")); // Only these containers are accepted.
        foreach ($rFiles as $rFile) {
            $rFilePath = "s:".intval($rRow["server_id"]).":".$rFile;
            if (!in_array($rFilePath, $rStreamDatabase)) {
                $rPathInfo = pathinfo($rFile);
                $rImportArray = Array("file" => $rFile, "stream_source" => Array($rFilePath), "stream_icon" => "", "stream_display_name" => $rPathInfo["filename"], "movie_propeties" => Array(), "target_container" => Array($rPathInfo["extension"]));
                $rImportStreams[] = $rImportArray;
            }
        }
        foreach ($rImportStreams as $rImportStream) {
            $rImportArray = $rArray;
            $rFile = $rImportStream["file"]; unset($rImportStream["file"]);
            foreach (array_keys($rImportStream) as $rKey) {
				$rImportArray[$rKey] = $rImportStream[$rKey];
            }
            $rFilename = pathinfo($rImportArray["stream_display_name"])["filename"];
            $rRelease = new Release($rFilename);
            $rTitle = $rRelease->getTitle();
            $rYear = $rRelease->getYear();
            $rResults = $rTMDB->searchMovie($rTitle);
            $rMatch = null;
            foreach ($rResults as $rResultArr) {
                if ($rYear) {
                    $rResultYear = intval(substr($rResultArr->get("release_date"), 0, 4));
                    if ($rResultYear == $rYear) {
                        $rMatch = $rResultArr;
                        break;
                    }
                } else {
                    $rMatch = $rResultArr;
                    break;
                }
            }
            $db->query("DELETE FROM `watch_output` WHERE `filename` = '".$db->real_escape_string($rFile)."';");
            if ($rMatch) {
                $rMovie = $rTMDB->getMovie($rMatch->get("id"));
                $rMovieData = json_decode($rMovie->getJSON(), True);
                $rMovieData["trailer"] = $rMovie->getTrailer();
                $rThumb = "https://image.tmdb.org/t/p/w600_and_h900_bestv2".$rMovieData['poster_path'];
                $rBG = "https://image.tmdb.org/t/p/w1280".$rMovieData['backdrop_path'];
                if ($rAdminSettings["download_images"]) {
                    $rThumb = downloadImage($rThumb);
                    $rBG = downloadImage($rBG);
                } else {
                    sleep(1); // Avoid limits.
                }
                $rCast = Array();
                foreach ($rMovieData["credits"]["cast"] as $rMember) {
                    if (count($rCast) < 5) {
                        $rCast[] = $rMember["name"];
                    }
                }
                $rDirectors = Array();
                foreach ($rMovieData["credits"]["crew"] as $rMember) {
                    if ((count($rDirectors) < 5) && ($rMember["department"] == "Directing")) {
                        $rDirectors[] = $rMember["name"];
                    }
                }
                $rCountry = "";
                if (isset($rMovieData["production_countries"][0]["name"])) {
                    $rCountry = $rMovieData["production_countries"][0]["name"];
                }
                $rGenres = Array();
                foreach ($rMovieData["genres"] as $rGenre) {
                    if (count($rGenres) < 3) {
                        $rGenres[] = $rGenre["name"];
                    }
                }
                $rSeconds = intval($rMovieData["runtime"]) * 60;
                $rImportArray["stream_display_name"] = $rMovieData["title"];
                $rImportArray["movie_propeties"] = Array("kinopoisk_url" => "https://www.themoviedb.org/movie/".$rMovieData["id"], "tmdb_id" => $rMovieData["id"], "name" => $rMovieData["title"], "o_name" => $rMovieData["original_title"], "cover_big" => $rThumb, "movie_image" => $rThumb, "releasedate" => $rMovieData["release_date"], "episode_run_time" => $rMovieData["runtime"], "youtube_trailer" => $rMovieData["trailer"], "director" => join(", ", $rDirectors), "actors" => join(", ", $rCast), "cast" => join(", ", $rCast), "description" => $rMovieData["overview"], "plot" => $rMovieData["overview"], "age" => "", "mpaa_rating" => "", "rating_count_kinopoisk" => 0, "country" => $rCountry, "genre" => join(", ", $rGenres), "backdrop_path" => Array($rBG), "duration_secs" => $rSeconds, "duration" => sprintf('%02d:%02d:%02d', ($rSeconds/3600),($rSeconds/60%60), $rSeconds%60), "video" => Array(), "audio" => Array(), "bitrate" => 0, "rating" => $rMovieData["vote_average"]);
                $rImportArray["read_native"] = $rWatchSettings["read_native"] ?: 1;
                $rImportArray["movie_symlink"] = $rWatchSettings["movie_symlink"] ?: 1;
                $rImportArray["transcode_profile_id"] = $rWatchSettings["transcode_profile_id"] ?: 0;
                $rImportArray["order"] = getNextOrder();
                $rPass = True;
                $rCategoryData = $rWatchCategories[intval($rMovieData["genres"][0]["id"])];
                if ($rRow["category_id"] > 0) {
                    $rImportArray["category_id"] = intval($rRow["category_id"]);
                } else {
                    $rImportArray["category_id"] = intval($rCategoryData["category_id"]);
                }
                $rORBouquets = json_decode($rRow["bouquets"], True);
                if (!$rORBouquets) {
                    $rORBouquets = Array();
                }
                if (count($rORBouquets) > 0) {
                    $rBouquets = json_decode($rRow["bouquets"], True);
                } else {
                    $rBouquets = json_decode($rCategoryData["category_id"], True);
                }
                if (!$rBouquets) { $rBouquets = Array(); }
                if ($rImportArray["category_id"] > 0) {
                    $rCols = "`".implode('`,`', array_keys($rImportArray))."`";
                    $rValues = null;
                    foreach (array_values($rImportArray) as $rValue) {
                        isset($rValues) ? $rValues .= ',' : $rValues = '';
                        if (is_array($rValue)) {
                            $rValue = json_encode($rValue);
                        }
                        if (is_null($rValue)) {
                            $rValues .= 'NULL';
                        } else {
                            $rValues .= '\''.$db->real_escape_string($rValue).'\'';
                        }
                    }
                    $rQuery = "INSERT INTO `streams`(".$db->real_escape_string($rCols).") VALUES(".$rValues.");";
                    if ($db->query($rQuery)) {
                        $rInsertID = $db->insert_id;
                        $db->query("INSERT INTO `streams_sys`(`stream_id`, `server_id`, `parent_id`, `on_demand`) VALUES(".intval($rInsertID).", ".intval($rRow["server_id"]).", 0, 0);");
                        if ($rWatchSettings["auto_encode"]) {
                            $rPost = Array("action" => "vod", "sub" => "start", "stream_ids" => Array($rInsertID));
                            $rContext = stream_context_create(array(
                                'http' => array(
                                    'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                                    'method'  => 'POST',
                                    'content' => http_build_query($rPost)
                                )
                            ));
                            $rRet = json_decode(file_get_contents($rAPI, false, $rContext), True);
                        }
                        foreach ($rBouquets as $rBouquet) {
                            addToBouquet("stream", $rBouquet, $rInsertID);
                            $rChanged = True;
                        }
                        // Success!
                        $db->query("INSERT INTO `watch_output`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(1, ".intval($rRow["server_id"]).", '".$db->real_escape_string($rFile)."', 1, ".intval($rInsertID).");");
                    } else {
                        // Insert failed.
                        $db->query("INSERT INTO `watch_output`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(1, ".intval($rRow["server_id"]).", '".$db->real_escape_string($rFile)."', 2, 0);");
                    }
                } else {
                    // No category.
                    $db->query("INSERT INTO `watch_output`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(1, ".intval($rRow["server_id"]).", '".$db->real_escape_string($rFile)."', 3, 0);");
                }
            } else {
                // No match.
                $db->query("INSERT INTO `watch_output`(`type`, `server_id`, `filename`, `status`, `stream_id`) VALUES(1, ".intval($rRow["server_id"]).", '".$db->real_escape_string($rFile)."', 4, 0);");
            }
        }
    }
}
if ($rChanged) {
    scanBouquets();
}
?>